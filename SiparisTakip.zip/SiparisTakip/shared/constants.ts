export const PRODUCT_LIST = [
  "033 ideal ped su",
  "050 ideal ped su", 
  "1.5 ideal ped su",
  "19 l ideal ped su",
  "5 l ideal ped su",
  "200 cl bardak su",
  "beypazari soda",
  "meyveli soda",
  "limonata",
  "gazoz",
  "karton bardak",
  "pet bardak"
];